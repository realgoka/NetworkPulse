# The app has no reflection-based model serialization and needs no custom rules.
