package com.netpulse.monitor

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.telephony.PhoneStateListener
import android.telephony.SignalStrength
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class MonitorService : Service() {
    private val running = AtomicBoolean(false)
    private val latestSignalDbm = AtomicInteger(NO_SIGNAL)
    private var scheduler: ScheduledExecutorService? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var measurementStore: MeasurementStore
    private lateinit var telephonyManager: TelephonyManager
    private var modernCallback: TelephonyCallback? = null
    private var legacyListener: PhoneStateListener? = null
    private var tickCount = 0L

    override fun onCreate() {
        super.onCreate()
        measurementStore = MeasurementStore(this)
        telephonyManager = getSystemService(TelephonyManager::class.java)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == MonitorContract.ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification(null, null, "Определение сети…"))
        startMonitoring()
        return START_STICKY
    }

    @SuppressLint("DiscouragedApi")
    private fun startMonitoring() {
        if (!running.compareAndSet(false, true)) return

        getSharedPreferences(MonitorContract.PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(MonitorContract.PREF_RUNNING, true)
            .apply()

        acquireWakeLock()
        registerSignalListener()

        scheduler = Executors.newSingleThreadScheduledExecutor { task ->
            Thread(task, "network-pulse-sampler").apply { priority = Thread.NORM_PRIORITY - 1 }
        }.also { executor ->
            executor.scheduleAtFixedRate(
                { safelyMeasure() },
                0L,
                SAMPLE_PERIOD_MS,
                TimeUnit.MILLISECONDS
            )
        }
    }

    private fun safelyMeasure() {
        try {
            val timestamp = System.currentTimeMillis()
            val pingMs = performIcmpPing()
            val signal = latestSignalDbm.get().takeIf { it != NO_SIGNAL }
            val connection = NetworkInfoUtil.connectionLabel(this)
            val measurement = Measurement(
                timestamp = timestamp,
                pingMs = pingMs,
                lost = pingMs == null,
                signalDbm = signal,
                connection = connection
            )

            measurementStore.insert(measurement)
            broadcastMeasurement(measurement)

            tickCount++
            if (tickCount % NOTIFICATION_REFRESH_TICKS == 0L) {
                getSystemService(NotificationManager::class.java).notify(
                    NOTIFICATION_ID,
                    buildNotification(pingMs, signal, connection)
                )
            }
            if (tickCount % PRUNE_TICKS == 0L) {
                measurementStore.prune(timestamp - DATABASE_RETENTION_MS)
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (_: Exception) {
            // A single failed sample must not terminate a long-running session.
        }
    }

    private fun performIcmpPing(): Float? {
        var process: Process? = null
        return try {
            process = ProcessBuilder(
                "/system/bin/ping",
                "-c", "1",
                "-W", "1",
                MonitorContract.PING_TARGET
            ).redirectErrorStream(true).start()

            val finished = process.waitFor(PING_PROCESS_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroyForcibly()
                null
            } else {
                val output = process.inputStream.bufferedReader().use { it.readText() }
                if (process.exitValue() != 0) {
                    null
                } else {
                    PING_TIME_REGEX.find(output)?.groupValues?.get(1)?.toFloatOrNull() ?: 1f
                }
            }
        } catch (_: Exception) {
            null
        } finally {
            process?.destroy()
        }
    }

    private fun broadcastMeasurement(measurement: Measurement) {
        val intent = Intent(MonitorContract.ACTION_MEASUREMENT)
            .setPackage(packageName)
            .putExtra(MonitorContract.EXTRA_TIMESTAMP, measurement.timestamp)
            .putExtra(MonitorContract.EXTRA_LOST, measurement.lost)
            .putExtra(MonitorContract.EXTRA_CONNECTION, measurement.connection)
            .putExtra(MonitorContract.EXTRA_HAS_SIGNAL, measurement.signalDbm != null)

        measurement.pingMs?.let { intent.putExtra(MonitorContract.EXTRA_PING_MS, it) }
        measurement.signalDbm?.let { intent.putExtra(MonitorContract.EXTRA_SIGNAL_DBM, it) }
        sendBroadcast(intent, MonitorContract.INTERNAL_PERMISSION)
    }

    private fun registerSignalListener() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val callback = object : TelephonyCallback(), TelephonyCallback.SignalStrengthsListener {
                    override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
                        latestSignalDbm.set(extractDbm(signalStrength) ?: NO_SIGNAL)
                    }
                }
                modernCallback = callback
                telephonyManager.registerTelephonyCallback(mainExecutor, callback)
            } else {
                @Suppress("DEPRECATION")
                val listener = object : PhoneStateListener() {
                    override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
                        latestSignalDbm.set(extractDbm(signalStrength) ?: NO_SIGNAL)
                    }
                }
                legacyListener = listener
                @Suppress("DEPRECATION")
                telephonyManager.listen(listener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS)
            }
        } catch (_: SecurityException) {
            latestSignalDbm.set(NO_SIGNAL)
        }
    }

    private fun unregisterSignalListener() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modernCallback?.let(telephonyManager::unregisterTelephonyCallback)
            } else {
                @Suppress("DEPRECATION")
                legacyListener?.let { telephonyManager.listen(it, PhoneStateListener.LISTEN_NONE) }
            }
        } catch (_: Exception) {
            // The radio process may disappear while the service is stopping.
        }
        modernCallback = null
        legacyListener = null
    }

    private fun extractDbm(signalStrength: SignalStrength): Int? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return signalStrength.cellSignalStrengths
                .asSequence()
                .map { it.dbm }
                .filter { it in VALID_DBM_RANGE }
                .maxOrNull()
        }

        @Suppress("DEPRECATION")
        val candidates = buildList {
            if (signalStrength.isGsm) {
                val asu = signalStrength.gsmSignalStrength
                if (asu in 0..31) add(-113 + 2 * asu)
            } else {
                add(signalStrength.cdmaDbm)
                add(signalStrength.evdoDbm)
            }
        }
        return candidates.filter { it in VALID_DBM_RANGE }.maxOrNull()
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireWakeLock() {
        val powerManager = getSystemService(PowerManager::class.java)
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "$packageName:NetworkSampling"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Активные ежесекундные замеры пинга и сигнала"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(pingMs: Float?, signalDbm: Int?, connection: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, MonitorService::class.java).setAction(MonitorContract.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val pingText = pingMs?.let { "${it.toInt()} мс" } ?: "потеря"
        val signalText = signalDbm?.let { "$it dBm" } ?: "нет данных"

        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText("$connection • $pingText • $signalText")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(
                Notification.Action.Builder(
                    null,
                    getString(R.string.notification_stop),
                    stopIntent
                ).build()
            )
            .build()
    }

    override fun onDestroy() {
        running.set(false)
        scheduler?.shutdownNow()
        scheduler = null
        unregisterSignalListener()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        getSharedPreferences(MonitorContract.PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(MonitorContract.PREF_RUNNING, false)
            .apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        measurementStore.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "network_monitoring"
        private const val NOTIFICATION_ID = 1001
        private const val SAMPLE_PERIOD_MS = 1_000L
        private const val PING_PROCESS_TIMEOUT_MS = 950L
        private const val NOTIFICATION_REFRESH_TICKS = 5L
        private const val PRUNE_TICKS = 3_600L
        private const val DATABASE_RETENTION_MS = 24L * 60L * 60L * 1000L
        private const val NO_SIGNAL = Int.MIN_VALUE
        private val VALID_DBM_RANGE = -150..-20
        private val PING_TIME_REGEX = Regex("""time[=<]\s*([0-9]+(?:\.[0-9]+)?)\s*ms""", RegexOption.IGNORE_CASE)
    }
}
