package com.netpulse.monitor

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.util.TypedValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

@SuppressLint("ViewConstructor")
class RealtimeChartView(
    context: Context,
    private val chartType: ChartType
) : View(context) {
    enum class ChartType { PING, SIGNAL }

    private val samples = ArrayList<Measurement>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val cardRect = RectF()
    private val plotRect = RectF()
    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private var visibleWindowMs = DEFAULT_WINDOW_MS.toDouble()
    private var offsetFromLatestMs = 0.0

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(
            e1: MotionEvent?,
            e2: MotionEvent,
            distanceX: Float,
            distanceY: Float
        ): Boolean {
            if (plotRect.width() <= 0f || samples.size < 2) return true
            offsetFromLatestMs -= distanceX / plotRect.width() * visibleWindowMs
            clampViewport()
            invalidate()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            visibleWindowMs = DEFAULT_WINDOW_MS.toDouble()
            offsetFromLatestMs = 0.0
            clampViewport()
            invalidate()
            return true
        }
    })

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (samples.size < 2 || plotRect.width() <= 0f) return true
                val oldWindow = visibleWindowMs
                val focusFraction = ((detector.focusX - plotRect.left) / plotRect.width())
                    .coerceIn(0f, 1f)
                    .toDouble()
                val latest = samples.last().timestamp.toDouble()
                val oldEnd = latest - offsetFromLatestMs
                val focusTime = oldEnd - oldWindow + focusFraction * oldWindow

                visibleWindowMs = (oldWindow / detector.scaleFactor)
                    .coerceIn(MIN_WINDOW_MS.toDouble(), MAX_WINDOW_MS.toDouble())
                val newEnd = focusTime + (1.0 - focusFraction) * visibleWindowMs
                offsetFromLatestMs = latest - newEnd
                clampViewport()
                invalidate()
                return true
            }
        })

    init {
        isFocusable = true
        contentDescription = if (chartType == ChartType.PING) {
            "График стабильности интернета"
        } else {
            "График силы сотового сигнала"
        }
    }

    @Synchronized
    fun setMeasurements(newSamples: List<Measurement>) {
        samples.clear()
        samples.addAll(newSamples)
        offsetFromLatestMs = 0.0
        clampViewport()
        invalidate()
    }

    @Synchronized
    fun append(measurement: Measurement) {
        val oldLatest = samples.lastOrNull()?.timestamp
        if (oldLatest != null && measurement.timestamp < oldLatest) return
        if (oldLatest != null && measurement.timestamp == oldLatest) {
            samples[samples.lastIndex] = measurement
        } else {
            val followingLive = offsetFromLatestMs < 1_500.0
            samples.add(measurement)
            if (!followingLive && oldLatest != null) {
                offsetFromLatestMs += measurement.timestamp - oldLatest
            }
        }

        val cutoff = measurement.timestamp - MonitorContract.HISTORY_MILLIS
        var removeCount = 0
        while (removeCount < samples.size && samples[removeCount].timestamp < cutoff) removeCount++
        if (removeCount > 0) samples.subList(0, removeCount).clear()
        clampViewport()
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
            parent?.requestDisallowInterceptTouchEvent(false)
            if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    @Synchronized
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawCard(canvas)
        if (width < dp(180f) || height < dp(130f)) return

        plotRect.set(dp(52f), dp(48f), width - dp(17f), height - dp(30f))
        val title = if (chartType == ChartType.PING) {
            "Стабильность Интернета (Пинг)"
        } else {
            "Сила Сотового Сигнала"
        }
        drawTitle(canvas, title)

        val latest = samples.lastOrNull()?.timestamp ?: System.currentTimeMillis()
        val endTime = latest - offsetFromLatestMs.toLong()
        val startTime = endTime - visibleWindowMs.toLong()
        val visible = samples.filter { it.timestamp in startTime..endTime }

        if (chartType == ChartType.PING) {
            drawPingChart(canvas, visible, startTime, endTime)
        } else {
            drawSignalChart(canvas, visible, startTime, endTime)
        }
        drawTimeAxis(canvas, startTime, endTime)

        if (visible.isEmpty()) drawEmptyState(canvas)
    }

    private fun drawCard(canvas: Canvas) {
        cardRect.set(0f, 0f, width.toFloat(), height.toFloat())
        fillPaint.color = COLOR_SURFACE
        canvas.drawRoundRect(cardRect, dp(18f), dp(18f), fillPaint)
    }

    private fun drawTitle(canvas: Canvas, title: String) {
        paint.color = COLOR_TEXT
        paint.textSize = sp(14f)
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        canvas.drawText(title, dp(17f), dp(27f), paint)

        paint.color = COLOR_MUTED
        paint.textSize = sp(9f)
        paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        canvas.drawText("Щипок — масштаб  •  сдвиг — история", dp(17f), dp(41f), paint)
    }

    private fun drawPingChart(
        canvas: Canvas,
        visible: List<Measurement>,
        startTime: Long,
        endTime: Long
    ) {
        val highest = visible.mapNotNull { it.pingMs }.maxOrNull() ?: 0f
        val yMax = when {
            highest <= 180f -> 200f
            highest <= 380f -> 400f
            else -> max(500f, ceil(highest / 100f) * 100f)
        }
        drawGridAndLabels(canvas, 0f, yMax, "мс")

        canvas.save()
        canvas.clipRect(plotRect)
        var previous: Measurement? = null
        for (sample in visible) {
            val x = xFor(sample.timestamp, startTime, endTime)
            if (sample.lost || sample.pingMs == null) {
                fillPaint.color = COLOR_LOSS_FAINT
                canvas.drawRect(x - dp(2f), plotRect.top, x + dp(2f), plotRect.bottom, fillPaint)
                linePaint.color = COLOR_RED
                linePaint.strokeWidth = dp(1.5f)
                val markerY = plotRect.bottom - dp(7f)
                canvas.drawLine(x - dp(4f), markerY - dp(4f), x + dp(4f), markerY + dp(4f), linePaint)
                canvas.drawLine(x - dp(4f), markerY + dp(4f), x + dp(4f), markerY - dp(4f), linePaint)
                previous = null
                continue
            }

            val prev = previous
            if (prev?.pingMs != null && sample.timestamp - prev.timestamp <= MAX_CONTINUOUS_GAP_MS) {
                val segmentValue = max(prev.pingMs, sample.pingMs)
                linePaint.color = pingColor(segmentValue)
                linePaint.strokeWidth = dp(2.2f)
                canvas.drawLine(
                    xFor(prev.timestamp, startTime, endTime),
                    yFor(prev.pingMs, 0f, yMax),
                    x,
                    yFor(sample.pingMs, 0f, yMax),
                    linePaint
                )
            }
            previous = sample
        }
        canvas.restore()

        val losses = visible.count { it.lost }
        val lossPercent = if (visible.isEmpty()) 0f else losses * 100f / visible.size
        paint.textSize = sp(10f)
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        paint.color = if (losses == 0) COLOR_GREEN else COLOR_RED
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Потери ${"%.1f".format(lossPercent)}%", plotRect.right, dp(27f), paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawSignalChart(
        canvas: Canvas,
        visible: List<Measurement>,
        startTime: Long,
        endTime: Long
    ) {
        val yMin = -120f
        val yMax = -50f
        drawGridAndLabels(canvas, yMin, yMax, "dBm")

        val path = Path()
        var hasPath = false
        var previousTime: Long? = null
        canvas.save()
        canvas.clipRect(plotRect)
        for (sample in visible) {
            val value = sample.signalDbm?.toFloat()
            if (value == null) {
                previousTime = null
                hasPath = false
                continue
            }
            val x = xFor(sample.timestamp, startTime, endTime)
            val y = yFor(value.coerceIn(yMin, yMax), yMin, yMax)
            if (!hasPath || previousTime == null || sample.timestamp - previousTime > MAX_CONTINUOUS_GAP_MS) {
                path.moveTo(x, y)
                hasPath = true
            } else {
                path.lineTo(x, y)
            }
            previousTime = sample.timestamp
        }
        linePaint.color = COLOR_CYAN
        linePaint.strokeWidth = dp(2.1f)
        canvas.drawPath(path, linePaint)
        canvas.restore()

        val latestSignal = visible.lastOrNull { it.signalDbm != null }?.signalDbm
        paint.textSize = sp(10f)
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        paint.color = signalColor(latestSignal)
        paint.textAlign = Paint.Align.RIGHT
        canvas.drawText(latestSignal?.let { "$it dBm" } ?: "Нет сигнала", plotRect.right, dp(27f), paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawGridAndLabels(canvas: Canvas, yMin: Float, yMax: Float, unit: String) {
        val lines = 4
        paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        paint.textSize = sp(9f)
        paint.textAlign = Paint.Align.RIGHT
        for (index in 0..lines) {
            val fraction = index / lines.toFloat()
            val y = plotRect.top + plotRect.height() * fraction
            linePaint.color = COLOR_GRID
            linePaint.strokeWidth = dp(1f)
            canvas.drawLine(plotRect.left, y, plotRect.right, y, linePaint)
            val value = yMax - (yMax - yMin) * fraction
            paint.color = COLOR_MUTED
            canvas.drawText("${value.toInt()}", plotRect.left - dp(7f), y + dp(3f), paint)
        }
        paint.textAlign = Paint.Align.LEFT
        paint.color = COLOR_MUTED
        paint.textSize = sp(8f)
        canvas.drawText(unit, dp(8f), plotRect.top - dp(5f), paint)
    }

    private fun drawTimeAxis(canvas: Canvas, startTime: Long, endTime: Long) {
        paint.color = COLOR_MUTED
        paint.textSize = sp(8f)
        paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        val times = longArrayOf(startTime, startTime + (endTime - startTime) / 2, endTime)
        val positions = floatArrayOf(plotRect.left, plotRect.centerX(), plotRect.right)
        val aligns = arrayOf(Paint.Align.LEFT, Paint.Align.CENTER, Paint.Align.RIGHT)
        for (index in times.indices) {
            paint.textAlign = aligns[index]
            canvas.drawText(timeFormatter.format(Date(times[index])), positions[index], height - dp(10f), paint)
        }
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawEmptyState(canvas: Canvas) {
        paint.color = COLOR_MUTED
        paint.textSize = sp(12f)
        paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("Ожидание данных", plotRect.centerX(), plotRect.centerY(), paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun xFor(timestamp: Long, startTime: Long, endTime: Long): Float {
        if (endTime <= startTime) return plotRect.right
        val fraction = (timestamp - startTime).toDouble() / (endTime - startTime).toDouble()
        return plotRect.left + plotRect.width() * fraction.toFloat()
    }

    private fun yFor(value: Float, yMin: Float, yMax: Float): Float {
        val fraction = (yMax - value) / (yMax - yMin)
        return plotRect.top + plotRect.height() * fraction
    }

    private fun pingColor(value: Float): Int = when {
        value < 50f -> COLOR_GREEN
        value <= 150f -> COLOR_YELLOW
        else -> COLOR_RED
    }

    private fun signalColor(value: Int?): Int = when {
        value == null -> COLOR_MUTED
        value >= -85 -> COLOR_GREEN
        value >= -105 -> COLOR_YELLOW
        else -> COLOR_RED
    }

    private fun clampViewport() {
        visibleWindowMs = visibleWindowMs.coerceIn(MIN_WINDOW_MS.toDouble(), MAX_WINDOW_MS.toDouble())
        if (samples.size < 2) {
            offsetFromLatestMs = 0.0
            return
        }
        val totalSpan = (samples.last().timestamp - samples.first().timestamp).coerceAtLeast(0L)
        val maximumOffset = max(0.0, totalSpan - visibleWindowMs)
        offsetFromLatestMs = offsetFromLatestMs.coerceIn(0.0, maximumOffset)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
    private fun sp(value: Float): Float = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_SP,
        value,
        resources.displayMetrics
    )

    companion object {
        private const val DEFAULT_WINDOW_MS = 60_000L
        private const val MIN_WINDOW_MS = 10_000L
        private const val MAX_WINDOW_MS = MonitorContract.HISTORY_MILLIS
        private const val MAX_CONTINUOUS_GAP_MS = 2_500L

        private val COLOR_SURFACE = Color.rgb(20, 26, 33)
        private val COLOR_GRID = Color.rgb(43, 53, 64)
        private val COLOR_TEXT = Color.rgb(244, 247, 250)
        private val COLOR_MUTED = Color.rgb(142, 156, 170)
        private val COLOR_GREEN = Color.rgb(51, 214, 166)
        private val COLOR_YELLOW = Color.rgb(255, 198, 71)
        private val COLOR_RED = Color.rgb(255, 87, 102)
        private val COLOR_CYAN = Color.rgb(65, 205, 255)
        private val COLOR_LOSS_FAINT = Color.argb(50, 255, 87, 102)
    }
}
