package com.netpulse.monitor

object MonitorContract {
    const val ACTION_START = "com.netpulse.monitor.action.START"
    const val ACTION_STOP = "com.netpulse.monitor.action.STOP"
    const val ACTION_MEASUREMENT = "com.netpulse.monitor.action.MEASUREMENT"

    const val EXTRA_TIMESTAMP = "timestamp"
    const val EXTRA_PING_MS = "ping_ms"
    const val EXTRA_LOST = "lost"
    const val EXTRA_SIGNAL_DBM = "signal_dbm"
    const val EXTRA_HAS_SIGNAL = "has_signal"
    const val EXTRA_CONNECTION = "connection"

    const val PREFS = "monitor_state"
    const val PREF_RUNNING = "running"
    const val INTERNAL_PERMISSION = "com.netpulse.monitor.permission.INTERNAL_MEASUREMENT"
    const val PING_TARGET = "8.8.8.8"
    const val HISTORY_MILLIS = 6L * 60L * 60L * 1000L
}

data class Measurement(
    val timestamp: Long,
    val pingMs: Float?,
    val lost: Boolean,
    val signalDbm: Int?,
    val connection: String
)
