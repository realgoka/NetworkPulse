package com.netpulse.monitor

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var startStopButton: Button
    private lateinit var statusText: TextView
    private lateinit var pingChart: RealtimeChartView
    private lateinit var signalChart: RealtimeChartView
    private lateinit var store: MeasurementStore

    private val mainHandler = Handler(Looper.getMainLooper())
    private val historyExecutor = Executors.newSingleThreadExecutor()
    private var receiverRegistered = false
    private var pendingStart = false
    private var displayedRunning: Boolean? = null
    private var displayedConnection: String? = null

    private val measurementReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != MonitorContract.ACTION_MEASUREMENT) return
            val lost = intent.getBooleanExtra(MonitorContract.EXTRA_LOST, true)
            val measurement = Measurement(
                timestamp = intent.getLongExtra(
                    MonitorContract.EXTRA_TIMESTAMP,
                    System.currentTimeMillis()
                ),
                pingMs = if (lost || !intent.hasExtra(MonitorContract.EXTRA_PING_MS)) {
                    null
                } else {
                    intent.getFloatExtra(MonitorContract.EXTRA_PING_MS, 0f)
                },
                lost = lost,
                signalDbm = if (intent.getBooleanExtra(MonitorContract.EXTRA_HAS_SIGNAL, false)) {
                    intent.getIntExtra(MonitorContract.EXTRA_SIGNAL_DBM, 0)
                } else {
                    null
                },
                connection = intent.getStringExtra(MonitorContract.EXTRA_CONNECTION) ?: "Нет сети"
            )
            pingChart.append(measurement)
            signalChart.append(measurement)
            renderState(true, measurement.connection)
        }
    }

    private val statusUpdater = object : Runnable {
        override fun run() {
            val running = isMonitoring()
            val connection = NetworkInfoUtil.connectionLabel(this@MainActivity)
            renderState(running, connection)
            mainHandler.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = MeasurementStore(this)
        configureSystemBars()
        buildInterface()
        startStopButton.setOnClickListener {
            if (isMonitoring()) stopMonitoring() else requestPermissionsAndStart()
        }
    }

    private fun configureSystemBars() {
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = COLOR_BACKGROUND
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BACKGROUND)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(dp(14), bars.top + dp(12), dp(14), bars.bottom + dp(12))
                insets
            }
        }

        startStopButton = Button(this).apply {
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.12f
            isAllCaps = false
            setTextColor(Color.rgb(5, 20, 17))
            gravity = Gravity.CENTER
            minHeight = dp(64)
            stateListAnimator = null
            contentDescription = "Запустить или остановить мониторинг"
        }
        root.addView(
            startStopButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64))
        )

        statusText = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            letterSpacing = 0.04f
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(
            statusText,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        pingChart = RealtimeChartView(this, RealtimeChartView.ChartType.PING)
        signalChart = RealtimeChartView(this, RealtimeChartView.ChartType.SIGNAL)

        root.addView(
            pingChart,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                bottomMargin = dp(10)
            }
        )
        root.addView(
            signalChart,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
        renderState(isMonitoring(), NetworkInfoUtil.connectionLabel(this))
    }

    private fun requestPermissionsAndStart() {
        val missing = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            missing += Manifest.permission.ACCESS_COARSE_LOCATION
            missing += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            missing += Manifest.permission.READ_PHONE_STATE
        }
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            missing += Manifest.permission.POST_NOTIFICATIONS
        }

        if (missing.isEmpty()) {
            startMonitoring()
        } else {
            pendingStart = true
            requestPermissions(missing.distinct().toTypedArray(), PERMISSION_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != PERMISSION_REQUEST || !pendingStart) return
        pendingStart = false
        if (corePermissionsGranted()) {
            startMonitoring()
        } else {
            Toast.makeText(
                this,
                "Для графика сотового сигнала нужны доступ к геопозиции и состоянию телефона.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun corePermissionsGranted(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun startMonitoring() {
        val intent = Intent(this, MonitorService::class.java).setAction(MonitorContract.ACTION_START)
        startForegroundService(intent)
        renderState(true, NetworkInfoUtil.connectionLabel(this))
    }

    private fun stopMonitoring() {
        stopService(Intent(this, MonitorService::class.java))
        getSharedPreferences(MonitorContract.PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(MonitorContract.PREF_RUNNING, false)
            .apply()
        renderState(false, NetworkInfoUtil.connectionLabel(this))
    }

    private fun isMonitoring(): Boolean =
        getSharedPreferences(MonitorContract.PREFS, Context.MODE_PRIVATE)
            .getBoolean(MonitorContract.PREF_RUNNING, false)

    private fun renderState(running: Boolean, connection: String) {
        if (displayedRunning == running && displayedConnection == connection) return
        displayedRunning = running
        displayedConnection = connection

        startStopButton.text = if (running) "СТОП" else "СТАРТ"
        startStopButton.background = roundedBackground(if (running) COLOR_STOP else COLOR_START)
        startStopButton.setTextColor(if (running) Color.WHITE else Color.rgb(5, 25, 20))
        statusText.text = if (running) {
            "●  ИЗМЕРЕНИЕ  •  $connection"
        } else {
            "●  ОЖИДАНИЕ  •  $connection"
        }
        statusText.setTextColor(if (running) COLOR_START else COLOR_MUTED)
    }

    private fun roundedBackground(color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(18).toFloat()
        setColor(color)
    }

    private fun loadHistory() {
        historyExecutor.execute {
            val measurements = store.loadRecent(System.currentTimeMillis() - MonitorContract.HISTORY_MILLIS)
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    pingChart.setMeasurements(measurements)
                    signalChart.setMeasurements(measurements)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            registerMeasurementReceiver()
        }
        loadHistory()
        mainHandler.post(statusUpdater)
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private fun registerMeasurementReceiver() {
        val filter = IntentFilter(MonitorContract.ACTION_MEASUREMENT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(measurementReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            // The custom signature permission makes the receiver private on Android 8–12.
            registerReceiver(
                measurementReceiver,
                filter,
                MonitorContract.INTERNAL_PERMISSION,
                null
            )
        }
        receiverRegistered = true
    }

    override fun onStop() {
        mainHandler.removeCallbacks(statusUpdater)
        if (receiverRegistered) {
            unregisterReceiver(measurementReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun onDestroy() {
        historyExecutor.shutdownNow()
        store.close()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val PERMISSION_REQUEST = 200
        private val COLOR_BACKGROUND = Color.rgb(11, 15, 20)
        private val COLOR_START = Color.rgb(51, 214, 166)
        private val COLOR_STOP = Color.rgb(214, 67, 81)
        private val COLOR_MUTED = Color.rgb(142, 156, 170)
    }
}
