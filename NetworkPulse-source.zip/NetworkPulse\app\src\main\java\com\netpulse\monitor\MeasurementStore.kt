package com.netpulse.monitor

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MeasurementStore(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    init {
        setWriteAheadLoggingEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE measurements (
                timestamp INTEGER PRIMARY KEY,
                ping_ms REAL,
                lost INTEGER NOT NULL,
                signal_dbm INTEGER,
                connection TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_measurements_timestamp ON measurements(timestamp)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun insert(measurement: Measurement) {
        val values = ContentValues().apply {
            put("timestamp", measurement.timestamp)
            if (measurement.pingMs == null) putNull("ping_ms") else put("ping_ms", measurement.pingMs)
            put("lost", if (measurement.lost) 1 else 0)
            if (measurement.signalDbm == null) putNull("signal_dbm") else put("signal_dbm", measurement.signalDbm)
            put("connection", measurement.connection)
        }
        writableDatabase.insertWithOnConflict(
            "measurements",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun loadRecent(since: Long, limit: Int = 21_600): List<Measurement> {
        val result = ArrayList<Measurement>()
        readableDatabase.rawQuery(
            """
            SELECT timestamp, ping_ms, lost, signal_dbm, connection
            FROM measurements
            WHERE timestamp >= ?
            ORDER BY timestamp DESC
            LIMIT ?
            """.trimIndent(),
            arrayOf(since.toString(), limit.toString())
        ).use { cursor ->
            val timestampIndex = cursor.getColumnIndexOrThrow("timestamp")
            val pingIndex = cursor.getColumnIndexOrThrow("ping_ms")
            val lostIndex = cursor.getColumnIndexOrThrow("lost")
            val signalIndex = cursor.getColumnIndexOrThrow("signal_dbm")
            val connectionIndex = cursor.getColumnIndexOrThrow("connection")
            while (cursor.moveToNext()) {
                result.add(
                    Measurement(
                        timestamp = cursor.getLong(timestampIndex),
                        pingMs = if (cursor.isNull(pingIndex)) null else cursor.getFloat(pingIndex),
                        lost = cursor.getInt(lostIndex) != 0,
                        signalDbm = if (cursor.isNull(signalIndex)) null else cursor.getInt(signalIndex),
                        connection = cursor.getString(connectionIndex)
                    )
                )
            }
        }
        result.reverse()
        return result
    }

    fun prune(before: Long) {
        writableDatabase.delete("measurements", "timestamp < ?", arrayOf(before.toString()))
    }

    companion object {
        private const val DATABASE_NAME = "network_pulse.db"
        private const val DATABASE_VERSION = 1
    }
}
